dpkg-deb --build mirthkit_1.2-1_i386
