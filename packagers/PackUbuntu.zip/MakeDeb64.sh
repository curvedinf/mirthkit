dpkg-deb --build mirthkit_1.2-1_amd64
